package stringbuffer;

/**
 * @author Elio
 * @version 1.0
 */
public class StringBufferMethod {
    public static void main(String[] args) {
        //StringBuffer methods
        StringBuffer stringBuffer = new StringBuffer("hello");
        //1.增
        stringBuffer.append(",");
        stringBuffer.append("张三丰");
        stringBuffer.append(true);
        System.out.println(stringBuffer);//hello,张三丰true

        //2.删
        stringBuffer.delete(5,7);
        System.out.println(stringBuffer); //hello三丰true

        //3. 修改
        stringBuffer.replace(5,7,"我是");
        System.out.println(stringBuffer);//hello我是true

        //4.查找指定的字串在字符串第一次出现的地方，如果没有返回-1
        System.out.println(stringBuffer.indexOf("l")); //2

        //5.插入,在索引处插入字符串，原来索引为9的内容自动后移
        stringBuffer.insert(2,"我猜");
        System.out.println(stringBuffer);//he我猜llo我是true

        //6.长度
        System.out.println(stringBuffer.length());

    }
}
