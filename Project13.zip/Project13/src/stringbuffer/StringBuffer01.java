package stringbuffer;

/**
 * @author Elio
 * @version 1.0
 */
public class StringBuffer01 {
    public static void main(String[] args) {
        //1.StringBuffer的直接父类是AbstractStringBuilder
        //2.它实现了Serializable,也就是可以串行化
        //3.在父类中，AbstractStringBuilder 有属性char[].不是final
        // 该value储存字符串内容，引出存放在堆里的
        //4.StringBuffer是一个final类，不能被继承
        //5. 由于StringBuffer 字符内容存在char[] value, 所以它是可变的.
        //StringBuffer 不用每次都改变地址,无需每次都创建一个新的字符串对象。
        StringBuffer sb1=new StringBuffer("hello");
    }
}
