package stringbuffer;

/**
 * @author Elio
 * @version 1.0
 */
public class StringAndStringBuffer {
    public static void main(String[] args) {
        //1.String 转换到StringBuffer
        String str1="hello tom";

        //方法1. 使用构造器
        //注意：返回的才是StringBuffer对象，对str本身没有影响
        StringBuffer stringBuffer = new StringBuffer(str1);

        //方法2 使用append方法
        StringBuffer stringBuffer1 = new StringBuffer();
        stringBuffer1=stringBuffer1.append(str1);
        System.out.println(stringBuffer1);


        //2.StringBuffer ->String
        StringBuffer stringBuffer2 = new StringBuffer("韩顺平教育");

        //方法1.使用SB提供的toString方法
        String s =stringBuffer2.toString();

        //方法2. 使用构造器.
        String s1 = new String(stringBuffer2);
    }
}
