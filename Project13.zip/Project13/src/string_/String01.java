package string_;

/**
 * @author Elio
 * @version 1.0
 */
public class String01 {
    public static void main(String[] args) {
        //String 对象用于保存字符串,也就是一组字符序列
        String name="jack";

        final char[] value ={'a','b'};
        char[] v2={'c','d'};

    }
}
