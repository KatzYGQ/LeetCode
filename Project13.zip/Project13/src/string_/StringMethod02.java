package string_;

/**
 * @author Elio
 * @version 1.0
 */
public class StringMethod02 {
    public static void main(String[] args) {
        //1. toUpperCase
        String s ="heLLO";
        System.out.println(s.toUpperCase());

        //2. toLowerCase
        System.out.println(s.toLowerCase());

        //3. concat 拼接
        String s1="";
        s1=s1.concat("黛玉").concat("宝钗").concat("together");
        System.out.println(s1);

        //4. replace
        s1="sadasadsakjldas";
        String s2="";
        s2=s1.replace("sad"," wocbin "); //s1并没有被真正替换.返回的结果才是
        System.out.println(s1);
        System.out.println(s2);

        //5. split 分割字符串,
        String poem = "锄禾日当午,hdhxt,szpzc,lljxk";
        //.以逗号(,)为标准对poem进行分割,返回一个数组
        //在对字符串进行分割时，如果有特殊字符，需要加入 转义符 \
        String[] split =poem.split(",");
        for(int i=0; i<split.length; i++){
            System.out.println(split[i]);
        }

        //6. toCharArray 转换成字符数组
        s="happy";
        char[] newS=s.toCharArray();
        for(int i=0; i<newS.length;i++){
            System.out.println(newS[i]);
        }

        //7. 比较两个字符串的大小, 如果前者大，返回正数, 后者大返回负数，如果相等返回0
        String a="jchn";
        String b="jack";
        System.out.println(a.compareTo(b)); //'c' - 'a' = 2

//      返回值是整型，它是先比较对应字符的大小(ASCII码顺序)，
//      如果第一个字符和参数的第一个字符不等，
//      结束比较，返回他们之间的长度差值，
//      如果第一个字符和参数的第一个字符相等，则以第二个字符和参数的第二个字符做比较，
//      以此类推,直至比较的字符或被比较的字符有一方结束。
//
//      如果参数字符串等于此字符串，则返回值 0；
//      如果此字符串小于字符串参数，则返回一个小于 0 的值；
//      如果此字符串大于字符串参数，则返回一个大于 0 的值。

        //8. format 格式字符串
        /*
        在Java中，格式化字符串通常是通过 String.format 方法或者 printf 方法实现的，
        这些方法使用一系列的占位符来插入和格式化值。以下是一些常用的格式化字符串占位符：

        %s - 字符串占位符。用于插入字符串。
        %d - 整数占位符。用于插入十进制整数。
        %f - 浮点数占位符。用于插入浮点数。
        %t - 日期/时间占位符。与后续字符结合使用来生成不同的日期和时间格式（例如 %tB 表示月份的全名，%tY 表示四位年份）。
        %c - 字符占位符。用于插入单个字符。
        %b - 布尔值占位符。用于插入布尔值，true 或 false。
        %e - 科学计数法占位符。用于以科学计数法格式化浮点数。
        %x 或 %X - 十六进制整数占位符。用于插入十六进制整数。
        %o - 八进制整数占位符。用于插入八进制整数。

        这些占位符可以结合标志、宽度、精度和转换类型来使用，以实现更复杂的格式化。例如：
        %6d 表示至少为6个字符宽的十进制整数，不足部分以空格填充。
        %.2f 表示保留两位小数的浮点数。
        */

        String name="John";
        int age=10;
        double score =98.3/3;
        char gender ='男';
        String formatStr="我的姓名是%s 年龄是%d, 成绩是%.2f 性别是%c";
        String info2=String.format(formatStr,name,age,score,gender);
        System.out.println(info2);
    }

}
