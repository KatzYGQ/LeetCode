package string_;

/**
 * @author Elio
 * @version 1.0
 */
public class StringUML {
    public static void main(String[] args) {

    }
}
