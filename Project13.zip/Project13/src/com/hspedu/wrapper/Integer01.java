package com.hspedu.wrapper;

/**
 * @author Elio
 * @version 1.0
 */
public class Integer01 {
    public static void main(String[] args) {
        //在JDK5之前
        //手动装箱
        int n1=100;
        //method 1
        Integer integer = new Integer(n1);
        //method 2
        Integer integer1 = Integer.valueOf(n1);

        //手动拆箱
        //Integer ->int
        int i = integer.intValue();

        int n2 =100;
        //在jdk5后，可以自动装箱拆箱
        //自动装箱 int->Integer
        Integer integer2 = n2; //底层使用的是new Integer(n2);

        //自动拆箱
        int n3=integer2;
    }
}
