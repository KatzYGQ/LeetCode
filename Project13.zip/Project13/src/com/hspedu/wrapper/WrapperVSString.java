package com.hspedu.wrapper;

/**
 * @author Elio
 * @version 1.0
 */
public class WrapperVSString {
    public static void main(String[] args) {
        //包装类(Integer)-> String
        Integer i=100;

        //method1.
        String str1= i+""; //i本身没有变化

        //method2.
        String str2=i.toString(); //i本身没有改变
        //method3
        String str3=String.valueOf(i);

        //String ->包装类(Integer)
        String str4= "1234";
        Integer i2=Integer.parseInt(str4); //自动装箱

        Integer i3=new Integer(str4); //构造器
        System.out.println("OK");

    }
}
