package com.hspedu.wrapper;

/**
 * @author Elio
 * @version 1.0
 */
public class WrapperType {
    public static void main(String[] args) {
        //boolean ->Boolean
        //char    ->Character
        //byte    ->Byte
        //int     ->Integer
        //long    ->Long
        //short   ->Short
        //double  ->Double
        //float   ->Float
    }
}
